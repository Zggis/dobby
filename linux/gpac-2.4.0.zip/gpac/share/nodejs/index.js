const gpac = require('bindings')('gpac');
module.exports = gpac;
