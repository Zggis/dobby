package com.gpac.mp4box;


public class mp4terminal {

	public native void run( String sCommandLine);
}
