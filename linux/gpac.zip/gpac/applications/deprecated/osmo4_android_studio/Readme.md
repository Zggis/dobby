# To compile this "to be improved" project

Compile libgpac and its dependencies using the scripts provided in build/android

Copy the content of applications/osmo4_android/libs into app/src/main/jniLibs

# A problem occurred starting process 'null/ndk-build'

Add this into your local.properties file

ndk.dir=/path/to/Android/sdk/ndk-bundle